protocole = 1;
publishedid = ;
name = "Civilian Presence Extended";
timestamp = 639003099990000000;