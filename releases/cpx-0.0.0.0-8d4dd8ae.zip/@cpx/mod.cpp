name = "Civilian Presence Extension";

author = "AWX Team";

// --- Expansions Menu ---
// Picture displayed from the expansions menu. Optimal size is 2048x1024
picture             = "";

// Overview text, displayed from the extension menu
overview            = "";

overviewPicture     = "";                             // Where?
overviewText        = "Civilian Presence Extension";         // Where?
overviewFootnote    = "Civilian Presence Extension";     // Where?

// Action Button, Label/Tooltip
actionName  = "";
// Action Button, Website URL
action      = "";
// Hide the extension name
hideName    = "false";
// Hide the extension menu
hidePicture = "false";


// --- Main Menu ---
// Logo displayed in the main menu 128x128
logo        = "";
// When the mouse is over, in the main menu 128x128
logoOver    = "";
// Tooltip when hovering over the Logo
tooltip         = "ACE Wardrobe Extended";

// Tool tip displayed when the mouse is left over, in the main menu
description     = "Civilian Presence Extension";      // Where?
tooltipOwned    = "Civilian Presence Extension";            // Where?


// --- Misc. ---
// Display next to the item added by the mod 64x64
logoSmall   = "";


// --- DLC ---
// Color used for DLC stripes and backgrounds (RGBA)
dlcColor[] =
{
    0.4117647058823529,
    0.0,
    0.0,
    1
};
